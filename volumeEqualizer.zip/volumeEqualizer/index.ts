/*
 * Vencord, a Discord client mod
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

import { definePluginSettings } from "../../api/Settings";
import definePlugin from "../../utils/types";
import { OptionType } from "../../utils/types";
import { Devs } from "../../utils/constants";
import { findByPropsLazy } from "../../webpack";

interface VoiceState {
    userId: string;
    volume: number;
}

// Get required Discord modules
const VoiceStateStore = findByPropsLazy("getVoiceStates", "getAllVoiceStates");
const MediaEngineStore = findByPropsLazy("getMediaEngine", "setVolume");

const settings = definePluginSettings({
    targetDecibel: {
        type: OptionType.NUMBER,
        description: "Target volume level (dB)",
        default: -20,
        minimum: -60,
        maximum: 0
    },
    enableEqualizer: {
        type: OptionType.BOOLEAN,
        description: "Enable volume equalization",
        default: true
    }
});

export default definePlugin({
    name: "VolumeEqualizer",
    description: "Automatically equalizes voice chat volumes to a target level",
    authors: [{
        name: "WyrdWonton",
        id: 1234567890n
    }],

    settings,

    start() {
        this.interval = setInterval(() => this.equalizeVoiceVolumes(), 1000);
    },

    stop() {
        if (this.interval) {
            clearInterval(this.interval);
            this.interval = null;
        }

        // Reset volumes to default
        const voiceStates = VoiceStateStore.getAllVoiceStates() as Record<string, { userId: string }>;
        for (const state of Object.values(voiceStates)) {
            if (state.userId) {
                MediaEngineStore.setVolume(state.userId, 100);
            }
        }
    },

    equalizeVoiceVolumes() {
        if (!settings.store.enableEqualizer) return;

        const targetDb = settings.store.targetDecibel;
        const voiceStates = VoiceStateStore.getAllVoiceStates() as Record<string, { userId: string }>;

        for (const state of Object.values(voiceStates)) {
            if (!state.userId) continue;

            // Get current volume level in dB
            const currentVolume = MediaEngineStore.getVolume(state.userId);
            const currentDb = 20 * Math.log10(currentVolume / 100);

            // Calculate required volume adjustment
            const dbDiff = targetDb - currentDb;
            const newVolume = Math.min(200, Math.max(0,
                currentVolume * Math.pow(10, dbDiff / 20)
            ));

            MediaEngineStore.setVolume(state.userId, newVolume);
        }
    }
});
